package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class CerrarCuenta extends JFrame {

    private JTextField tfID;
    private JLabel lblNombre, lblSaldo, lblEstado;

    public CerrarCuenta() {

        setTitle("Cerrar Cuenta");
        setSize(450, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(15, 20, 15, 20));
        add(panel);

        // --- FORM ---
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8,8,8,8);
        g.fill = GridBagConstraints.HORIZONTAL;

        // ID
        g.gridx = 0; g.gridy = 0;
        form.add(new JLabel("ID de Cuenta:"), g);

        g.gridx = 1;
        tfID = new JTextField();
        form.add(tfID, g);

        JButton btnBuscar = new JButton("Buscar");
        g.gridx = 2;
        form.add(btnBuscar, g);

        // Info mostrada
        g.gridx = 0; g.gridy = 1;
        form.add(new JLabel("Titular:"), g);

        g.gridx = 1;
        lblNombre = new JLabel("-");
        form.add(lblNombre, g);

        g.gridx = 0; g.gridy = 2;
        form.add(new JLabel("Saldo:"), g);

        g.gridx = 1;
        lblSaldo = new JLabel("-");
        form.add(lblSaldo, g);

        g.gridx = 0; g.gridy = 3;
        form.add(new JLabel("Estado:"), g);

        g.gridx = 1;
        lblEstado = new JLabel("-");
        form.add(lblEstado, g);

        panel.add(form, BorderLayout.CENTER);

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnCerrar = new JButton("Cerrar Cuenta");
        JButton btnCancelar = new JButton("Cancelar");

        panelBotones.add(btnCerrar);
        panelBotones.add(btnCancelar);

        panel.add(panelBotones, BorderLayout.SOUTH);

        // Eventos
        btnCancelar.addActionListener(e -> dispose());

        btnBuscar.addActionListener(e -> buscarCuenta());

        btnCerrar.addActionListener(e -> cerrarCuenta());

        setVisible(true);
    }

    private Cuenta cuentaActual = null;

    private void buscarCuenta() {
        String id = tfID.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese el ID.");
            return;
        }

        cuentaActual = GestorCuentas.buscar(id);

        if (cuentaActual == null) {
            JOptionPane.showMessageDialog(this, "Cuenta no encontrada.");
            limpiarDatos();
            return;
        }

        lblNombre.setText(cuentaActual.getNombre());
        lblSaldo.setText(String.valueOf(cuentaActual.getSaldo()));
        lblEstado.setText(cuentaActual.isCerrada() ? "CERRADA" : "ACTIVA");
    }

    private void limpiarDatos() {
        lblNombre.setText("-");
        lblSaldo.setText("-");
        lblEstado.setText("-");
        cuentaActual = null;
    }

    private void cerrarCuenta() {
        if (cuentaActual == null) {
            JOptionPane.showMessageDialog(this, "Primero busque una cuenta.");
            return;
        }

        if (cuentaActual.isCerrada()) {
            JOptionPane.showMessageDialog(this, "La cuenta ya está cerrada.");
            return;
        }

        if (cuentaActual.getSaldo() != 0) {
            JOptionPane.showMessageDialog(this, "El saldo debe ser 0 para cerrar la cuenta.");
            return;
        }

        int conf = JOptionPane.showConfirmDialog(
                this,
                "¿Desea cerrar la cuenta: " + cuentaActual.getNumero() + "?",
                "Confirmación",
                JOptionPane.YES_NO_OPTION
        );

        if (conf == JOptionPane.YES_OPTION) {
            boolean ok = GestorCuentas.cerrarCuenta(cuentaActual.getNumero());

            if (ok) {
                JOptionPane.showMessageDialog(this, "Cuenta cerrada con éxito.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo cerrar la cuenta.");
            }
        }
    }
}



