package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Retirar extends JFrame {

    public Retirar() {
        setTitle("Retirar");
        setSize(460, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Panel principal con margen
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(15, 20, 15, 20));
        add(panelPrincipal);

        // Formulario centrado
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Número de cuenta
        gbc.gridx = 0; gbc.gridy = 0;
        form.add(new JLabel("Número de cuenta:"), gbc);

        gbc.gridx = 1;
        JTextField tfNumero = new JTextField();
        form.add(tfNumero, gbc);

        // Monto a retirar
        gbc.gridx = 0; gbc.gridy = 1;
        form.add(new JLabel("Monto a retirar:"), gbc);

        gbc.gridx = 1;
        JTextField tfMonto = new JTextField();
        form.add(tfMonto, gbc);

        panelPrincipal.add(form, BorderLayout.CENTER);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnRetirar = new JButton("Retirar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnRetirar);
        panelBotones.add(btnCancelar);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // Acciones
        btnCancelar.addActionListener(e -> dispose());

        btnRetirar.addActionListener(e -> {
            String num = tfNumero.getText().trim();
            double monto;

            try {
                monto = Double.parseDouble(tfMonto.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Monto inválido.");
                return;
            }

            Cuenta c = GestorCuentas.buscar(num);
            if (c == null) {
                JOptionPane.showMessageDialog(this, "Cuenta no encontrada.");
                return;
            }
            if (c.isCerrada()) {
                JOptionPane.showMessageDialog(this, "Cuenta está cerrada.");
                return;
            }
            if (c.getSaldo() < monto) {
                JOptionPane.showMessageDialog(this, "Saldo insuficiente.");
                return;
            }

            int conf = JOptionPane.showConfirmDialog(
                this, "¿Retirar $" + monto + " de la cuenta " + num + "?",
                "Confirmar", JOptionPane.YES_NO_OPTION
            );

            if (conf == JOptionPane.YES_OPTION) {
                if (GestorCuentas.retirar(num, monto)) {
                    JOptionPane.showMessageDialog(this, "Retiro realizado.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo retirar.");
                }
            }
        });

        setVisible(true);
    }
}
