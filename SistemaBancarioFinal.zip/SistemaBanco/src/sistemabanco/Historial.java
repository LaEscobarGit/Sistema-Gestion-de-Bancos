package sistemabanco;

import java.awt.BorderLayout;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Historial extends JFrame {

    private static final String ARCHIVO_HISTORIAL = "historial.txt";

    public Historial() {

        setTitle("Historial de Transacciones");
        setSize(700, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // --- Panel principal ---
        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Cuentas Activas", crearPanelActivas());
        tabs.add("Cuentas Cerradas", crearPanelCerradas());

        add(tabs);
        setVisible(true);
    }

    // ==========================================================
    // PANEL DE TRANSACCIONES ACTIVAS
    // ==========================================================
    private JPanel crearPanelActivas() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        List<String[]> datos = cargarHistorialFiltrado(false); // false = activas

        if (datos.isEmpty()) {
            panel.add(new JLabel("No hay transacciones de cuentas activas."), BorderLayout.CENTER);
            return panel;
        }

        String[] columnas = {"Fecha", "Tipo", "Monto", "ID"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);

        for (String[] fila : datos) modelo.addRow(fila);

        JTable tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // ==========================================================
    // PANEL DE TRANSACCIONES DE CUENTAS CERRADAS
    // ==========================================================
    private JPanel crearPanelCerradas() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        List<String[]> datos = cargarHistorialFiltrado(true); // true = cerradas

        if (datos.isEmpty()) {
            panel.add(new JLabel("No hay transacciones de cuentas cerradas."), BorderLayout.CENTER);
            return panel;
        }

        String[] columnas = {"Fecha", "Tipo", "Monto", "ID"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0);

        for (String[] fila : datos) modelo.addRow(fila);

        JTable tabla = new JTable(modelo);
        JScrollPane scroll = new JScrollPane(tabla);
        panel.add(scroll, BorderLayout.CENTER);

        return panel;
    }

    // ==========================================================
    // LECTURA DE HISTORIAL + FILTRO
    // ==========================================================
    private List<String[]> cargarHistorialFiltrado(boolean cerradas) {

        List<String[]> resultado = new ArrayList<>();
        List<Cuenta> cuentas = GestorCuentas.cargarCuentas();

        // convertir lista a un mapa rápido ID→cuenta
        Map<String, Cuenta> mapa = new HashMap<>();
        for (Cuenta c : cuentas) mapa.put(c.getNumero(), c);

        File f = new File(ARCHIVO_HISTORIAL);
        if (!f.exists()) return resultado;

        List<String[]> temporal = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                if (linea.trim().isEmpty()) continue;

                // FORMATO: "FECHA | TIPO | ... | Cuenta: ID"
                String fecha = extraerFecha(linea);
                String tipo = extraerTipo(linea);
                String monto = extraerMonto(linea);
                String id = extraerID(linea);

                if (id == null) continue;

                Cuenta c = mapa.get(id);
                if (c == null) continue;

                // filtrado
                if (cerradas && !c.isCerrada()) continue;
                if (!cerradas && c.isCerrada()) continue;

                temporal.add(new String[]{fecha, tipo, monto, id});
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // ORDENAR (más recientes últimas → invertimos)
        Collections.reverse(temporal);

        // LIMITE
        int limite = cerradas ? 10 : 20;
        for (int i = 0; i < temporal.size() && i < limite; i++) {
            resultado.add(temporal.get(i));
        }

        return resultado;
    }

    // ==========================================================
    // PARSERS DEL FORMATO DEL HISTORIAL
    // ==========================================================
    private String extraerFecha(String linea) {
        // si no tienes fecha, puedes poner una artificial
        return new Date().toString();
    }

    private String extraerTipo(String linea) {
        if (linea.contains("CREACION")) return "CREACIÓN";
        if (linea.contains("CIERRE")) return "CIERRE";
        if (linea.contains("DEPOSITO")) return "DEPÓSITO";
        if (linea.contains("RETIRO")) return "RETIRO";
        if (linea.contains("TRANSFERENCIA SALIENTE")) return "TRANSFERENCIA OUT";
        if (linea.contains("TRANSFERENCIA ENTRANTE")) return "TRANSFERENCIA IN";
        return "DESCONOCIDO";
    }

    private String extraerMonto(String linea) {
        int idx = linea.indexOf("| +");
        if (idx != -1) return linea.substring(idx + 2).trim();

        idx = linea.indexOf("| -");
        if (idx != -1) return linea.substring(idx + 2).trim();

        return "0";
    }

    private String extraerID(String linea) {
        // busca "Cuenta:" o "Origen:" o "Destino:"
        if (linea.contains("Cuenta:")) {
            return linea.substring(linea.indexOf("Cuenta:") + 7).trim().split(" ")[0];
        }
        if (linea.contains("Origen:")) {
            return linea.substring(linea.indexOf("Origen:") + 7).trim().split(" ")[0];
        }
        if (linea.contains("Destino:")) {
            return linea.substring(linea.indexOf("Destino:") + 8).trim().split(" ")[0];
        }
        return null;
    }
}
