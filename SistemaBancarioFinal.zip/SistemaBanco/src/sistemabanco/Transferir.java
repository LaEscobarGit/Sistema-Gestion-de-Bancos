package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Transferir extends JFrame {

    public Transferir() {
        setTitle("Transferir");
        setSize(500, 260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Panel principal con margen
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(15, 20, 15, 20));
        add(panelPrincipal);

        // Formulario
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Cuenta origen
        gbc.gridx = 0; gbc.gridy = 0;
        form.add(new JLabel("Cuenta origen:"), gbc);

        gbc.gridx = 1;
        JTextField tfOrigen = new JTextField();
        form.add(tfOrigen, gbc);

        // Cuenta destino
        gbc.gridx = 0; gbc.gridy = 1;
        form.add(new JLabel("Cuenta destino:"), gbc);

        gbc.gridx = 1;
        JTextField tfDestino = new JTextField();
        form.add(tfDestino, gbc);

        // Monto
        gbc.gridx = 0; gbc.gridy = 2;
        form.add(new JLabel("Monto:"), gbc);

        gbc.gridx = 1;
        JTextField tfMonto = new JTextField();
        form.add(tfMonto, gbc);

        panelPrincipal.add(form, BorderLayout.CENTER);

        // Botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnTransferir = new JButton("Transferir");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnTransferir);
        panelBotones.add(btnCancelar);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // Acciones
        btnCancelar.addActionListener(e -> dispose());

        btnTransferir.addActionListener(e -> {

            String origen = tfOrigen.getText().trim();
            String destino = tfDestino.getText().trim();
            double monto;

            if (origen.isEmpty() || destino.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete las cuentas.");
                return;
            }
            if (origen.equals(destino)) {
                JOptionPane.showMessageDialog(this, "Las cuentas no pueden ser iguales.");
                return;
            }

            try {
                monto = Double.parseDouble(tfMonto.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Monto inválido.");
                return;
            }

            Cuenta cO = GestorCuentas.buscar(origen);
            Cuenta cD = GestorCuentas.buscar(destino);

            if (cO == null) {
                JOptionPane.showMessageDialog(this, "Cuenta origen no encontrada.");
                return;
            }
            if (cD == null) {
                JOptionPane.showMessageDialog(this, "Cuenta destino no encontrada.");
                return;
            }
            if (cO.isCerrada() || cD.isCerrada()) {
                JOptionPane.showMessageDialog(this, "Alguna cuenta está cerrada.");
                return;
            }
            if (cO.getSaldo() < monto) {
                JOptionPane.showMessageDialog(this, "Saldo insuficiente en la cuenta origen.");
                return;
            }

            int conf = JOptionPane.showConfirmDialog(
                this,
                "¿Transferir $" + monto + " de " + origen + " a " + destino + "?",
                "Confirmar",
                JOptionPane.YES_NO_OPTION
            );

            if (conf == JOptionPane.YES_OPTION) {
                if (GestorCuentas.transferir(origen, destino, monto)) {
                    JOptionPane.showMessageDialog(this, "Transferencia realizada.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo realizar la transferencia.");
                }
            }
        });

        setVisible(true);
    }
}
