package sistemabanco;

import com.formdev.flatlaf.FlatDarkLaf;
import java.awt.*;
import javax.swing.*;

public class Menu extends JFrame {
    
    GestorCuentas gestor = new GestorCuentas();

    public Menu() {

        setTitle("Gestión de Cuentas Bancarias");
        setSize(1024, 576);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Panel principal
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2, 20, 20));
        panel.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40));
        
       JMenuBar menuBar = new JMenuBar();
       JMenu menuFile = new JMenu("File");
       JMenuItem itemExit = new JMenuItem("Exit");
       JMenu menuHelp = new JMenu("Help");
        JMenuItem itemAbout = new JMenuItem("About");

        // Botones del sistema
        JButton btnCrear = new JButton("Crear Cuenta");
        JButton btnCerrar = new JButton("Cerrar Cuenta");
        JButton btnModificar = new JButton("Modificar Nombre");
        JButton btnDepositar = new JButton("Depositar");
        JButton btnRetirar = new JButton("Retirar");
        JButton btnTransferir = new JButton("Transferir");
        JButton btnConsultas = new JButton("Consulta Particular");
        JButton btnConsultaGeneral = new JButton("Consulta General");
        JButton btnHistorial = new JButton("Historial");

        panel.add(btnCrear);
        panel.add(btnCerrar);
        panel.add(btnModificar);
        panel.add(btnDepositar);
        panel.add(btnRetirar);
        panel.add(btnTransferir);
        panel.add(btnConsultas);
        panel.add(btnHistorial);
        panel.add(btnConsultaGeneral);
        
        menuFile.add(itemExit);
        menuHelp.add(itemAbout);
        menuBar.add(menuFile);
        menuBar.add(menuHelp);
        setJMenuBar(menuBar);

        add(panel);

        // Acciones
        btnCrear.addActionListener(e -> new CrearCuenta());
        btnCerrar.addActionListener(e -> new CerrarCuenta());
        btnModificar.addActionListener(e -> new ModificarNombre());
        btnDepositar.addActionListener(e -> new Depositar());
        btnRetirar.addActionListener(e -> new Retirar());
        btnTransferir.addActionListener(e -> new Transferir());
        btnConsultas.addActionListener(e -> new Consultas().setVisible(true));
        btnConsultaGeneral.addActionListener(e -> new ConsultaGeneral().setVisible(true));
        btnHistorial.addActionListener(e -> new Historial().setVisible(true));
        
        // Acciones del menú
        itemAbout.addActionListener(e -> {
            JOptionPane.showMessageDialog(
                this,
            "Sistema de Gestión Bancaria\n"
            + "Versión 0.1\n\n"
            + "Desarrollado por:\n"
            + "Miguel Angel Padilla Cerda\n"
            + "Roberto Espinoza Lopez\n\n"
            + "© 2025",
            "Acerca de",
            JOptionPane.INFORMATION_MESSAGE
            );
        });
        
        itemExit.addActionListener(e -> System.exit(0));
        
    }

    public static void main(String[] args) {
        
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize Look and Feel");
    }
        
        Login login = new Login();
        login.setVisible(true);
        
    }
}
