package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class CrearCuenta extends JFrame {

    public CrearCuenta() {

        setTitle("Crear Cuenta");
        setSize(450, 260);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // --- Panel principal con márgenes ---
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(15, 20, 15, 20)); // márgenes
        add(panelPrincipal);

        // --- Panel del formulario ---
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        gbc.insets = new Insets(8, 8, 8, 8); // espacio entre controles
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Nombre
        gbc.gridx = 0; gbc.gridy = 0;
        form.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        JTextField tfNombre = new JTextField();
        form.add(tfNombre, gbc);

        // Saldo inicial
        gbc.gridx = 0; gbc.gridy = 1;
        form.add(new JLabel("Saldo inicial:"), gbc);

        gbc.gridx = 1;
        JTextField tfSaldo = new JTextField("0");
        form.add(tfSaldo, gbc);

        panelPrincipal.add(form, BorderLayout.CENTER);

        // --- Panel inferior con botones ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnCrear = new JButton("Crear");
        JButton btnCancelar = new JButton("Cancelar");

        panelBotones.add(btnCrear);
        panelBotones.add(btnCancelar);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // --- Eventos ---
        btnCancelar.addActionListener(e -> dispose());

        btnCrear.addActionListener(e -> {
            String nom = tfNombre.getText().trim();
            double saldo;

            if (nom.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese el nombre.");
                return;
            }

            try {
                saldo = Double.parseDouble(tfSaldo.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Saldo inválido.");
                return;
            }

            String[] salida = new String[1];
            boolean ok = GestorCuentas.crearCuentaAuto(nom, saldo, salida);

            if (ok) {
                String id = salida[0] != null ? salida[0] : "Desconocido";
                JOptionPane.showMessageDialog(this, "Cuenta creada con ID: " + id);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo crear la cuenta.");
            }
        });

        setVisible(true);
    }
}

