package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class Consultas extends JFrame {

    private JTextField txtID;
    private JTable tabla;
    private DefaultTableModel modelo;

    public Consultas() {

        setTitle("Consulta de Cuenta por ID");
        setSize(520, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);

        // Panel principal
        JPanel panelPrincipal = new JPanel(new GridBagLayout());

        JPanel panelContenido = new JPanel(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // ===== Etiqueta e input =====
        JLabel lID = new JLabel("Ingrese ID de cuenta:");
        lID.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        txtID = new JTextField(15);

        gbc.gridx = 0;  gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panelContenido.add(lID, gbc);

        gbc.gridx = 1;  
        gbc.anchor = GridBagConstraints.WEST;
        panelContenido.add(txtID, gbc);

        // ===== Botón =====
        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        gbc.gridx = 0; 
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        panelContenido.add(btnBuscar, gbc);

        // ===== Tabla =====
        String[] columnas = {"ID", "Titular", "Saldo", "Estado"};
        modelo = new DefaultTableModel(columnas, 0);

        tabla = new JTable(modelo);
        tabla.setRowHeight(22);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setPreferredSize(new Dimension(460, 150));

        gbc.gridy = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panelContenido.add(scroll, gbc);

        panelPrincipal.add(panelContenido);
        add(panelPrincipal);

        // Evento del botón
        btnBuscar.addActionListener(e -> buscarCuenta());
    }

    private void buscarCuenta() {
        modelo.setRowCount(0); // limpiar tabla

        String id = txtID.getText().trim();

        // Validación de entrada
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Debe ingresar un ID.",
                    "ID inválido",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Buscar cuenta
        Cuenta c = GestorCuentas.buscar(id);

        // Si NO existe
        if (c == null) {
            JOptionPane.showMessageDialog(this,
                    "No existe una cuenta con ese ID.",
                    "No encontrada",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Si está cerrada
        if (c.isCerrada()) {
            JOptionPane.showMessageDialog(this,
                    "La cuenta está cerrada y no puede consultarse.",
                    "Cuenta cerrada",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Agregar datos reales a la tabla
        modelo.addRow(new Object[]{
                c.getNumero(),
                c.getNombre(),
                c.getSaldo(),
                "Activa"
        });
    }
}