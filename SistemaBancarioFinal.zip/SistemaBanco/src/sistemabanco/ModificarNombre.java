package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class ModificarNombre extends JFrame {

    public ModificarNombre() {
        setTitle("Modificar Nombre");
        setSize(460, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // --- Panel principal ---
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(15, 20, 15, 20));
        add(panelPrincipal);

        // --- Formulario ---
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Campo ID
        gbc.gridx = 0; gbc.gridy = 0;
        form.add(new JLabel("Número de cuenta:"), gbc);

        gbc.gridx = 1;
        JTextField tfNumero = new JTextField();
        form.add(tfNumero, gbc);

        // Campo nombre nuevo
        gbc.gridx = 0; gbc.gridy = 1;
        form.add(new JLabel("Nuevo nombre:"), gbc);

        gbc.gridx = 1;
        JTextField tfNuevo = new JTextField();
        form.add(tfNuevo, gbc);

        panelPrincipal.add(form, BorderLayout.CENTER);

        // --- Botones ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnModificar = new JButton("Modificar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnModificar);
        panelBotones.add(btnCancelar);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // --- Acciones ---
        btnCancelar.addActionListener(e -> dispose());

        btnModificar.addActionListener(e -> {
            String num = tfNumero.getText().trim();
            String nuevo = tfNuevo.getText().trim();

            if (num.isEmpty() || nuevo.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Complete los datos.");
                return;
            }

            Cuenta c = GestorCuentas.buscar(num);
            if (c == null) {
                JOptionPane.showMessageDialog(this, "Cuenta no encontrada.");
                return;
            }
            if (c.isCerrada()) {
                JOptionPane.showMessageDialog(this, "La cuenta está cerrada.");
                return;
            }

            int conf = JOptionPane.showConfirmDialog(
                this, "¿Modificar nombre de la cuenta " + num + "?",
                "Confirmar", JOptionPane.YES_NO_OPTION
            );

            if (conf == JOptionPane.YES_OPTION) {
                if (GestorCuentas.modificarNombre(num, nuevo)) {
                    JOptionPane.showMessageDialog(this, "Nombre actualizado.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo modificar.");
                }
            }
        });

        setVisible(true);
    }
}
