package sistemabanco;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Depositar extends JFrame {

    public Depositar() {
        setTitle("Depositar");
        setSize(460, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // --- Panel principal ---
        JPanel panelPrincipal = new JPanel(new BorderLayout());
        panelPrincipal.setBorder(new EmptyBorder(15, 20, 15, 20));
        add(panelPrincipal);

        // --- Formulario ---
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Campo ID
        gbc.gridx = 0; gbc.gridy = 0;
        form.add(new JLabel("Número de cuenta:"), gbc);

        gbc.gridx = 1;
        JTextField tfNumero = new JTextField();
        form.add(tfNumero, gbc);

        // Campo monto
        gbc.gridx = 0; gbc.gridy = 1;
        form.add(new JLabel("Monto a depositar:"), gbc);

        gbc.gridx = 1;
        JTextField tfMonto = new JTextField();
        form.add(tfMonto, gbc);

        panelPrincipal.add(form, BorderLayout.CENTER);

        // --- Botones ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        JButton btnDepositar = new JButton("Depositar");
        JButton btnCancelar = new JButton("Cancelar");
        panelBotones.add(btnDepositar);
        panelBotones.add(btnCancelar);

        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);

        // --- Acciones ---
        btnCancelar.addActionListener(e -> dispose());

        btnDepositar.addActionListener(e -> {
            String num = tfNumero.getText().trim();
            double monto;

            try {
                monto = Double.parseDouble(tfMonto.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Monto inválido.");
                return;
            }

            Cuenta c = GestorCuentas.buscar(num);
            if (c == null) {
                JOptionPane.showMessageDialog(this, "Cuenta no encontrada.");
                return;
            }
            if (c.isCerrada()) {
                JOptionPane.showMessageDialog(this, "La cuenta está cerrada.");
                return;
            }

            int conf = JOptionPane.showConfirmDialog(
                this, "¿Depositar $" + monto + " a la cuenta " + num + "?",
                "Confirmar", JOptionPane.YES_NO_OPTION
            );

            if (conf == JOptionPane.YES_OPTION) {
                if (GestorCuentas.depositar(num, monto)) {
                    JOptionPane.showMessageDialog(this, "Depósito realizado.");
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "No se pudo depositar.");
                }
            }
        });

        setVisible(true);
    }
}