package sistemabanco;

import java.awt.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class ConsultaGeneral extends JFrame {

    public ConsultaGeneral() {
        setTitle("Consulta General de Cuentas");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ===== Cargar solo cuentas activas =====
        List<Cuenta> todas = GestorCuentas.cargarCuentas();
        List<Cuenta> activas = new ArrayList<>();

        for (Cuenta c : todas) {
            if (!c.isCerrada()) {
                activas.add(c);
            }
        }

        if (activas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay cuentas activas registradas.");
            dispose();
            return;
        }

        // ===== Título =====
        JLabel lblTitulo = new JLabel("Cuentas Activas", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setBorder(new EmptyBorder(10, 10, 10, 10));
        add(lblTitulo, BorderLayout.NORTH);

        // ===== Crear tabla =====
        String[] columnas = {"Número", "Nombre", "Saldo", "Estado"};
        String[][] datos = new String[activas.size()][4];

        for (int i = 0; i < activas.size(); i++) {
            Cuenta c = activas.get(i);
            datos[i][0] = c.getNumero();
            datos[i][1] = c.getNombre();
            datos[i][2] = "" + c.getSaldo();
            datos[i][3] = "Activa";
        }

        JTable tabla = new JTable(datos, columnas);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tabla.setRowHeight(22);
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));

        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(new EmptyBorder(10, 20, 10, 20));

        add(scroll, BorderLayout.CENTER);

        // ===== Botón de cerrar =====
        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.addActionListener(e -> dispose());

        JPanel panelBoton = new JPanel();
        panelBoton.add(btnCerrar);

        add(panelBoton, BorderLayout.SOUTH);
    }
}
